require 'active_model/observing'
# disabled until they're tested
# require 'active_model/callbacks'
# require 'active_model/validations'
require 'active_model/base'