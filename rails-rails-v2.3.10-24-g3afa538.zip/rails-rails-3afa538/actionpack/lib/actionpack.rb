require 'action_pack'
ActiveSupport::Deprecation.warn 'require "actionpack" is deprecated and will be removed in Rails 3. Use require "action_pack" instead.'
