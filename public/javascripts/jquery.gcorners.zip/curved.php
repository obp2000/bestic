<?
// set the HTTP header type to PNG
header("Content-type: image/png"); 

// set the width and height of the new image in pixels
$width = $_GET['w'];
$height = $_GET['h'];
$color = $_GET['c'];

if($_GET['w'] == '') $width = 10;
if($_GET['h'] == '') $height = 10;
if($_GET['c'] == '') $color = '000000';

//increment to avoid clipping
$width++;
$height++;
 
// create a pointer to a new true colour image
$im = ImageCreateTrueColor($width, $height); 
ImageAntiAlias($im, true);
$trans = ImageColorAllocate($im, 255, 0, 255); 
imagecolortransparent($im, $trans);
ImageFillToBorder($im, 0, 0, $trans, $trans);
 
// define colour and draw ellipse
$ellipseColour = ImageColorAllocate($im, hexrgb($color, 'r'), hexrgb($color, 'g'), hexrgb($color, 'b'));
ImageFilledEllipse($im, ($width/2), ($height/2), $width, $height, $ellipseColour);
 
// send the new PNG image to the browser
ImagePNG($im); 
ImageDestroy($im); 


//Convert hex colour string to RGB values
function hexrgb($hexstr, $rgb) {
	$int = hexdec($hexstr);
	switch($rgb) {
        case "r":
        return 0xFF & $int >> 0x10;
            break;
        case "g":
        return 0xFF & ($int >> 0x8);
            break;
        case "b":
        return 0xFF & $int;
            break;
        default:
        return array(
            "r" => 0xFF & $int >> 0x10,
            "g" => 0xFF & ($int >> 0x8),
            "b" => 0xFF & $int
            );
            break;
    }   
}
?>