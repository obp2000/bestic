<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
<title>PHP Curved Corners</title>
<link rel="stylesheet" href="style.css" type="text/css" media="screen" />
<script type="text/javascript" src="scripts/jquery.js"></script>
<script type="text/javascript" src="scripts/jquery.gcorners.js"></script>
<script type="text/javascript">
$(document).ready(function(){
   $('#content').gcorners({height:10, width:10, color:'97BE97'});
   $('#content1').gcorners({ width:30, color:'00BF85'});
});
</script>
</head>
<body>
	<div id="content">
		<h1>Hello World</h1>
		<p>This is some text...</p>
	</div>
	<br />
	<div id="content1">
		<h1>Hello World</h1>
		<p>This is some text...</p>
	</div>
</body>
</html>
